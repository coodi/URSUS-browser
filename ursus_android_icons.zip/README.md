# Ursus Browser Android launcher icons

Готовый набор ресурсов для Android. Скопируйте содержимое `app/src/main/res/` в соответствующий каталог проекта.

В `AndroidManifest.xml` используйте:

```xml
android:icon="@mipmap/ic_launcher"
android:roundIcon="@mipmap/ic_launcher_round"
```

Состав:
- legacy PNG: mdpi 48×48, hdpi 72×72, xhdpi 96×96, xxhdpi 144×144, xxxhdpi 192×192;
- adaptive icon XML для API 26+;
- foreground PNG;
- monochrome PNG для themed icons;
- background color `#0E5A43`.

Примечание: исходный арт сгенерирован растровым, поэтому foreground/monochrome здесь PNG, а не VectorDrawable.
